# app/__init__.py
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__, template_folder='C:/Users/divya/Documents/EarlyDiaScan/templates', static_folder='C:/Users/divya/Documents/EarlyDiaScan/static')
    app.config['SECRET_KEY'] = 'your_secret_key'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 587
    app.config['MAIL_USE_TLS'] = True
    app.config['MAIL_USERNAME'] = 'divyanshpaliya720@gmail.com'
    app.config['MAIL_PASSWORD'] = 'bozu rpnc qdam jwgu'
    app.config['MAIL_DEFAULT_SENDER'] = 'divyanshpaliya720@gmail.com'

    from flask_mail import Mail
    global mail
    mail = Mail(app)

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'login'

    from .routes import routes
    app.register_blueprint(routes)

    return app
