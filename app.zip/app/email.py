# app/email.py
from flask_mail import Message
from flask import url_for
from . import mail

def send_welcome_email(user_email, user_firstname):
    msg = Message(
    subject='Welcome to EarlyDiaScan!',
    recipients=[user_email],
    body=f'''
Hello {user_firstname},

Welcome to EarlyDiaScan! 👋

We are very happy to have you with us.
EarlyDiaScan helps you quickly assess your risk of diabetes through simple questionnaires and scanning technology.

By detecting early signs, you can take the right steps towards a healthier future.

If you ever need any help or have questions, just reply to this email — we're here to support you!

Stay healthy and take care,
The EarlyDiaScan Team
'''
)
    mail.send(msg)
