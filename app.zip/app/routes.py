# app/routes.py
from flask import Blueprint, render_template, redirect, url_for, flash, session
from flask_login import login_user, login_required, logout_user, current_user
from .models import User
from .models import Report
from .forms import LoginForm, RegisterForm
from werkzeug.security import generate_password_hash, check_password_hash
from . import db, login_manager
from werkzeug.security import check_password_hash
from flask import request
from .email import send_welcome_email
import pandas as pd
import joblib  

model = joblib.load("diabetes_model.pkl")
feature_names = [
    'Age Group', 'Polyuria(High Urine Output)', 'Polydipsia(Excessive Thirst)', 'Sudden Weight Loss', 'Weakness',
    'Polyphagia(Excessive Hunger)', 'Genital thrush', 'Visual Blurring', 'Itching', 'Irritability',
    'Delayed Healing', 'Obesity'
]

routes = Blueprint('routes', __name__)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@routes.route('/')
def home():
    return redirect(url_for('routes.dashboard'))

@routes.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    message = None  # Initialize message

    if request.method == 'POST':
        if form.validate_on_submit():
            email = form.email.data
            password = form.password.data

            # Fetch the user from the database
            user = User.query.filter_by(email=email).first()

            # Check if user exists and the password matches
            if user and check_password_hash(user.password, password):
                login_user(user)
                return redirect(url_for('routes.dashboard'))
            else:
                message = "User does not exist or password is incorrect."

    return render_template('login.html', form=form, message=message)

@routes.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data, method='pbkdf2:sha256')
        new_user = User(
            first_name=form.first_name.data,
            last_name=form.last_name.data,
            email=form.email.data,
            password=hashed_password
        )
        db.session.add(new_user)
        db.session.commit()

        send_welcome_email(form.email.data, form.first_name.data)

        return redirect(url_for('routes.login'))
    return render_template('register.html', form=form)

@routes.route('/dashboard')
def dashboard():
    if current_user.is_authenticated:
        first_name = current_user.first_name
        last_name = current_user.last_name
        return render_template('dashboard.html', first_name=first_name, last_name=last_name, logged_in=True)
    else:
        return render_template('dashboard.html', logged_in=False)

@routes.route('/logout')
# @login_required
def logout():
    logout_user()
    flash('Logged out.')
    return redirect(url_for('routes.login'))

@routes.route('/risk_scan')
@login_required
def risk_scan():
    return render_template("risk_scan.html")

@routes.route('/parameter-insights')
# @login_required
def parameter_insights():
    return render_template("parameter-insights.html")

@routes.route('/previous_report_score')
# @login_required
def previous_report_score():
    report_list = Report.query.order_by(Report.date.desc()).all()
    return render_template('previous_report.html', reports=report_list)

@routes.route('/bmi-calculator', methods=['GET', 'POST'])
# @login_required
def bmi_calculator():
    bmi_result = None
    category = None

    if request.method == 'POST':
        try:
            weight = float(request.form['weight'])
            height = float(request.form['height']) / 100
            bmi = round(weight / (height ** 2), 1)
            bmi_result = bmi

            if bmi < 18.5:
                category = "Underweight"
            elif 18.5 <= bmi <= 24.9:
                category = "Normal"
            elif 25 <= bmi <= 29.9:
                category = "Overweight"
            else:
                category = "Obese"
        except:
            bmi_result = "Invalid input"
            category = ""

    return render_template('bmi-calculator.html', bmi_result=bmi_result, category=category)

def get_risk_description(score):
    if 0 <= score <= 25:
        return "You currently have a low likelihood of developing diabetes. Continue maintaining a healthy lifestyle to keep your risk low. Regular check-ups and preventive care are still recommended."
    elif 26 <= score <= 50:
        return "You have a moderate chance of developing diabetes. This suggests early signs may be present. Adopting healthier eating habits, increasing physical activity, and regular monitoring can significantly reduce your risk."
    elif 51 <= score <= 75:
        return "You are at a high risk of developing diabetes. Several contributing factors may be present. It's important to take proactive steps, including lifestyle changes and consulting a healthcare provider."
    elif 76 <= score <= 100:
        return "You have a very high likelihood of developing diabetes. Immediate lifestyle intervention and medical evaluation are strongly recommended to prevent or manage the condition effectively."
    else:
        return "Invalid score."

@routes.route('/report', methods=['GET','POST'])
@login_required
def report():
    if request.method == 'POST':
        try:
            input_values = [
                int(request.form.get("age_group")),
                int(request.form.get("polyuria")),
                int(request.form.get("polydipsia")),
                int(request.form.get("sudden_weight_loss")),
                int(request.form.get("weakness")),
                int(request.form.get("polyphagia")),
                int(request.form.get("genital_thrush")),
                int(request.form.get("visual_blurring")),
                int(request.form.get("itching")),
                int(request.form.get("irritability")),
                int(request.form.get("delayed_healing")),
                int(request.form.get("obesity"))
            ]
            name = request.form.get('name')
            mobile = request.form.get('mobile')
            email = request.form.get('email')
            date = request.form.get('date')

            input_df = pd.DataFrame([input_values], columns=feature_names)
            prediction = (model.predict_proba(input_df)[0][1] * 100).round(1)
            score = prediction
            description = get_risk_description(score)

            # Store in database
            new_report = Report(name=name, mobile=mobile, date=date, prediction=score)
            db.session.add(new_report)
            db.session.commit()

            # Store in session temporarily
            session['report_data'] = {
                'prediction': float(prediction),
                'name': name,
                'mobile': mobile,
                'email': email,
                'date': date,
                'risk_description': description
            }

            return redirect(url_for('routes.result_page'))

        except Exception as e:
            return f"Error in prediction: {e}", 500
        
    return redirect(url_for('routes.home'))
    
@routes.route('/result_page')
@login_required
def result_page():
    report_data = session.pop('report_data', None)
    if not report_data:
        return redirect(url_for('routes.risk_scan'))

    return render_template("result.html", **report_data)

@routes.route('/delete/<int:id>')
def delete(id):
    delrep = Report.query.filter_by(id=id).first()
    db.session.delete(delrep)
    db.session.commit()
    return redirect(url_for('routes.previous_report_score'))